package com.example.nopause;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** 只作用于元萝卜的 :stubN 进程(分身应用所在进程)，让 Activity 不进入暂停/停止。 */
public class Hook implements IXposedHookLoadPackage {
    private static final String HOST = "top.bienvenido.saas.i18n";
    private static final String TAG = "[NoPause] ";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!HOST.equals(lp.packageName)) return;
        String proc = lp.processName == null ? "" : lp.processName;
        if (!proc.contains(":stub")) return;   // 不动元萝卜自己的界面进程
        XposedBridge.log(TAG + "hook " + proc);

        // 1) 跳过 onPause / onStop (仅在 Activity 没在退出时)
        XC_MethodHook skipIfAlive = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Activity a = (Activity) p.thisObject;
                if (!a.isFinishing()) p.setResult(null);
            }
        };
        hookAll(Activity.class, "performPause", skipIfAlive);
        hookAll(Activity.class, "performStop", skipIfAlive);

        // 2) 阻止窗口被隐藏 (否则 SurfaceView/GLSurfaceView 会销毁 surface)
        XC_MethodHook skipHide = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                Object last = p.args.length > 0 ? p.args[p.args.length - 1] : null;
                if (last instanceof Boolean && !((Boolean) last)) p.setResult(null);
            }
        };
        try {
            Class<?> at = XposedHelpers.findClass("android.app.ActivityThread", lp.classLoader);
            hookAll(at, "updateVisibility", skipHide);
            hookAll(at, "handleWindowVisibility", skipHide);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "ActivityThread hook fail: " + t);
        }

        // 3) 窗口失焦/不再是顶层 -> 一律当作仍有焦点 (游戏常在失焦时暂停)
        XC_MethodHook alwaysTrue = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                if (p.args.length > 0 && p.args[0] instanceof Boolean) p.args[0] = Boolean.TRUE;
            }
        };
        hookAll(View.class, "dispatchWindowFocusChanged", alwaysTrue);
        hookAll(ViewGroup.class, "dispatchWindowFocusChanged", alwaysTrue);
        hookAll(Activity.class, "onTopResumedActivityChanged", alwaysTrue);
    }

    private static void hookAll(Class<?> c, String name, XC_MethodHook cb) {
        try {
            int n = XposedBridge.hookAllMethods(c, name, cb).size();
            XposedBridge.log(TAG + c.getSimpleName() + "." + name + " x" + n);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "fail " + name + ": " + t);
        }
    }
}
